//: Playground - noun: a place where people can play

import Foundation

/* ADAPTOR PATTERN:
** Adapt the incompatible interface to the one we require.
** Many times legacy or third party code cannot be modified but it has to be integrated in our app/framework.
** Adaptor extends or wraps the incompatible entity and give the required interface
*/

protocol Sharing {
	func share(message: String, completionHandler: @escaping(Error?)->Void)
}

class FBSharer: Sharing {
	public func share(message: String, completionHandler: @escaping(Error?)->Void) {
		print("Message[\(message)] shared on FB...")
		completionHandler(nil)
	}
}

class TwitterSharer: Sharing {
	public func share(message: String, completionHandler: @escaping(Error?)->Void) {
		print("Message[\(message)] shared on Twitter...")
		completionHandler(nil)
	}
}

enum SharerType: String, CustomStringConvertible {
	case facebook = "facebook"
	case twitter = "twitter"
	case reddit = "reddit"

	var description: String {
		switch self {
		case .facebook:
			return "facebook"
		case .twitter:
			return "twitter"
		case .reddit:
			return "reddit"
		default:
			return "unknown"
		}
	}
}

class Sharer {

	let shareServices: [SharerType: Sharing] = [.facebook: FBSharer(), .twitter: TwitterSharer(), .reddit: RedditSharerAdaptor()]

	public func shareEverywhere(message: String) {
		for (serviceType,sharer) in shareServices {
			sharer.share(message: message, completionHandler: {(error) in
				if error != nil {
					print("Could not share on \(serviceType.description)")
				}
			})
		}
	}

	public func shareOn(shareType: SharerType, message: String, completionHandler: @escaping(Error?)->Void) {
		if let sharer = shareServices[shareType] {
			sharer.share(message: message, completionHandler: completionHandler)
		}
	}
}

let sharer = Sharer()
sharer.shareEverywhere(message: "Hello World!")
sharer.shareOn(shareType: .facebook, message: "Hi bubbles", completionHandler: {(error) in
	if error != nil {
		print("Could not share")
	}
})

class RedditPoster {
	func post(text: String, completion:@escaping(Error?, UUID?)->Void) {
		print("Message[\(text)] posted to Reddit")
		completion(nil, UUID())
	}
}

// Technique 1
class RedditSharerAdaptor: Sharing {
	private lazy var redditPoster = RedditPoster()

	public func share(message: String, completionHandler: @escaping(Error?)->Void) {
		redditPoster.post(text: message, completion: {(error, uuid) in
			completionHandler(error)
		})
	}
}

// Technique 2
extension RedditPoster: Sharing {
	public func share(message: String, completionHandler: @escaping(Error?)->Void) {
		self.post(text: message, completion: {(error, uuid) in
			completionHandler(error)
		})
	}
}
